DEPENDENCIES:
PyTorch
Pandas
Numpy
matplotlib
deap

Run GA.py to run Genetic Algorithm that optimises for hyper-parameters of Casper neural network and tests the optimal parameters

Run LoadTrainTest.py to only train and test a single Casper network with predefined hyper-parameters in main()